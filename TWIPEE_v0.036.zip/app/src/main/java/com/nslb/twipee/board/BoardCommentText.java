package com.nslb.twipee.board;

public class BoardCommentText {
    private String UserID;
    private String CommentText;
    private String Date;
}
