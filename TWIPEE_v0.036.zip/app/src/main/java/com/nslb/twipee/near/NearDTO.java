package com.nslb.twipee.near;

public class NearDTO {
    private int resId_near;
    private String position;
    private int resld_position;
    public int getResId_near(){return resId_near;}
    public void setResId_near(int resId_near){this.resId_near=resId_near;}
    public String getPosition(){return position;}
    public void setPosition(String position){this.position=position;}
    public int getResld_position(){return resld_position; }
    public void setResld_position(int resld_position){this.resld_position=resld_position;}


}
