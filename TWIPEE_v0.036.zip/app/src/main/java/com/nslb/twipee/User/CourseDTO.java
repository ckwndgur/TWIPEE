package com.nslb.twipee.User;

public class CourseDTO {
    private int resld_positionimage;
    private String cou_position;
    private String cou_pos_detail;
    private String phone_number;
    private String time;
    public int getResld_positionimage(){return resld_positionimage;}
    public void setResld_positionimage(int resld_positionimage){this.resld_positionimage=resld_positionimage;}
    public String getCou_position(){return cou_position;}
    public void setCou_position(String cou_position){this.cou_position=cou_position;}
    public String getCou_pos_detail(){return cou_pos_detail;}
    public void setCou_pos_detail(String cou_pos_detail){this.cou_pos_detail=cou_pos_detail;}
    public String getPhone_number(){return phone_number;}
    public void setPhone_number(String phone_number){this.phone_number=phone_number;}
    public String getTime(){return time;}
    public void setTime(String time){this.time=time;}
}
