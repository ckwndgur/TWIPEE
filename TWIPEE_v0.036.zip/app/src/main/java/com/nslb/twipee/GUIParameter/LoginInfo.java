package com.nslb.twipee.GUIParameter;

public class LoginInfo {
    final public int USERNAME = 0;
    final public int LOGINID = 1;
    final public int LOGINPW = 2;
    final public int BIRTHDAY = 3;
}
