package com.nslb.twipee.board;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Board_detail extends AppCompatActivity {
    private Intent intent;
    private ImageView imageView;
    private TextView textView;
    @Override
    protected void onCreate(@Nullable Bundle savedIstanceState){
        super.onCreate(savedIstanceState);

    }
}
