package com.nslb.twipee.ui;

import com.google.android.material.tabs.TabLayout;

public interface MyEventListener {
    void onTabSelected(TabLayout.Tab tab);
}
