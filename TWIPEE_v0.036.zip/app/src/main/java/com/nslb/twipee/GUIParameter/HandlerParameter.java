package com.nslb.twipee.GUIParameter;

public class HandlerParameter {
    public final int XMLTOURINFO = 0;
    public final int URLIMAGESINGLE = 1;
    public final int URLIMAGELIST = 2;
}
