package com.nslb.twipee.User;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.nslb.twipee.R;

public class OtherUserInfo extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userinfo_other);

    }
}