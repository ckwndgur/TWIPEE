package com.nslb.twipee.User;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.nslb.twipee.R;

public class SetUp extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_setup);
    }
}